The `profiles` folder is used to store user custom profiles.
